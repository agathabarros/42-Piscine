/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   interval_space.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: agpereir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/24 19:57:43 by agpereir          #+#    #+#             */
/*   Updated: 2023/03/24 20:06:29 by agpereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>


char	ft_strlen(char *str)
{
	int	j;
	
	j = 0;
	while (str[j] != '\0')
	{
		j++;
	}
	return (j);
}
int	main(int ac, char **av)
{
	int	i;
	int	len;

	i = 0;
	len = ft_strlen(*av);
	if (ac > 1 && av[1][0] != '\0')
	{
		while (av[1][i] > '\0' && i < len -1)
		{
			write (1, &av[1][i], 1);
			write (1, "   ", 3);
			i++;
		}
		if (1 <= len - 1)
		{
			write (1, &av[1][i], 1);
		}
	}
	write (1, "\n", 1);
}
